import React, { useState } from 'react';
import AthleteForm from './AthleteForm';
import AthleteList from './AthleteList';

const AthleteApp = () => {
  const [athletes, setAthletes] = useState([]);

  const handleAddAthlete = (athleteData) => {
    setAthletes([...athletes, athleteData]);
  };

  const handleDeleteAthlete = (athleteId) => {
    setAthletes(athletes.filter((athlete) => athlete.id !== athleteId));
  };

  return (
    <div>
      <AthleteForm onSubmit={handleAddAthlete} />
      <AthleteList athletes={athletes} onDelete={handleDeleteAthlete} />
    </div>
  );
};

export default AthleteApp;