import React from 'react';
import AthleteData from './AthleteData';

const AthleteList = ({ athletes }) => {
  return (
    <div>
      <h2>Lista de Atletas</h2>
      <ul>
        {athletes.map((athlete) => (
          <li key={athlete.id}>
            <AthleteData athleteData={athlete} />
          </li>
        ))}
      </ul>
    </div>
  );
};

export default AthleteList;