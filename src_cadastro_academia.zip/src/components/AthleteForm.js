
import React, { useState } from 'react';
import './AthleteForm.css';

const AthleteForm = () => {
  const [athleteData, setAthleteData] = useState({
    name: '',
    birthdate: '',
    email: '',
    phone: '',
    belt: '',
    category: '',
    weight: '',
  });

  const handleSubmit = (event) => {
    event.preventDefault();
    // Salvar os dados do atleta
  };

  return (
    <form onSubmit={handleSubmit}>
      <h1>Academia de Jiu Jitsu</h1>
      <h2>Cadastro Geral</h2>
      <h3>Dados Pessoais</h3>
      <label>
        Nome:
        <input type="text" value={athleteData.name} onChange={(event) => setAthleteData({ ...athleteData, name: event.target.value })} />
      </label>
      <label>
        Data de Nascimento:
        <input type="date" value={athleteData.birthdate} onChange={(event) => setAthleteData({ ...athleteData, birthdate: event.target.value })} />
      </label>
      <label>
        E-mail:
        <input type="email" value={athleteData.email} onChange={(event) => setAthleteData({ ...athleteData, email: event.target.value })} />
      </label>
      <label>
        Telefone:
        <input type="tel" value={athleteData.phone} onChange={(event) => setAthleteData({ ...athleteData, phone: event.target.value })} />
      </label>

      <h3>Informações de Graduação de Faixa</h3>
      <select value={athleteData.belt} onChange={(event) => setAthleteData({ ...athleteData, belt: event.target.value })}>
        <option value="">Selecione</option>
        <option value="branca">Branca</option>
        <option value="cinza">Cinza</option>
        <option value="amarela">Amarela</option>
        <option value="laranja">Laranja</option>
        <option value="verde">Verde</option>
        <option value="azul">Azul</option>
        <option value="roxa">Roxa</option>
        <option value="marrom">Marrom</option>
        <option value="preta">Preta</option>
      </select>

      <h3>Informações de Categoria</h3>
      <select value={athleteData.category} onChange={(event) => setAthleteData({ ...athleteData, category: event.target.value })}>
        <option value="">Selecione</option>
        <option value="mirim">Mirim</option>
        <option value="infantil">Infantil</option>
        <option value="juvenil">Juvenil</option>
        <option value="adulto">Adulto</option>
        <option value="master">Master</option>
      </select>

      <h3>Informações de Peso</h3>
      <select value={athleteData.weight} onChange={(event) => setAthleteData({ ...athleteData, weight: event.target.value })}>
        <option value="">Selecione</option>
        <option value="galo">Galo</option>
        <option value="pluma">Pluma</option>
        <option value="pena">Pena</option>
        <option value="leve">Leve</option>
        <option value="medio">Médio</option>
        <option value="meio-pesado">Meio Pesado</option>
        <option value="pesado">Pesado</option>
        <option value="super-pesado">Super Pesado</option>
        <option value="pesadissimo">Pesadíssimo</option>
      </select>

      <button type="submit">Salvar</button>
      <button type="button">Cancelar</button>
    </form>
  );
};

export default AthleteForm;