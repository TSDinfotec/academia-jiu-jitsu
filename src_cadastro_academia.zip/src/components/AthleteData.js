import React from 'react';

const AthleteData = ({ athleteData }) => {
  return (
    <div>
      <h2>Dados do Atleta</h2>
      <p>Nome: {athleteData.name}</p>
      <p>Data de Nascimento: {athleteData.birthdate}</p>
      <p>E-mail: {athleteData.email}</p>
      <p>Telefone: {athleteData.phone}</p>
      <p>Graduação de Faixa: {athleteData.belt}</p>
      <p>Categoria: {athleteData.category}</p>
      <p>Peso: {athleteData.weight}</p>
    </div>
  );
};

export default AthleteData;