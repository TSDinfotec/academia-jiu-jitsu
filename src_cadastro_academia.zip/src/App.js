import './App.css';
import AthleteForm from './components/AthleteForm';

function App() {
  return (
    
    <div className="App">   
           
        <AthleteForm/>
    </div>
  
    
  );
}

export default App;
